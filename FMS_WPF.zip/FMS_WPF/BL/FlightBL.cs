﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Flight_Entity;
using FlightException;
using DAL;
using System.Text.RegularExpressions;

namespace BL
{
    public class FlightBL
    {

        private static bool ValidationFlightBL(Flight_46004312 newFlight)
        {
            bool valid = true;
            StringBuilder sb = new StringBuilder();
            if (newFlight.departure.Estimated == null || newFlight.departure.Scheduled == null || newFlight.departure.Actual == null)
            {
                valid = false;
                sb.Append(Environment.NewLine + "Departure can't be null");
            }

            if (!Regex.IsMatch(newFlight.GateNo, "^[0-9]+$"))
            {
                valid = false;
                sb.Append(Environment.NewLine + "GateNo should be number");
            }

            if (!Regex.IsMatch(newFlight.Destination, "^[A-Za-z]+$"))
            {
                valid = false;
                sb.Append(Environment.NewLine + "Destination should be string");
            }

            if (valid == false)
                throw new FlightExceptions(sb.ToString());
            return valid;

        }


        public static bool AddFlightBL(Flight_46004312 newFlight)
        {
            bool FlightAdded = false;

            try
            {
                if (ValidationFlightBL(newFlight))
                {
                    FlightAdded = FlightDAL.AddFlightDAL(newFlight);
                }
                else
                {
                    throw new FlightExceptions(Environment.NewLine + "Flight details entered are not Valid!");
                }
            }
            catch (FlightExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return FlightAdded;
        }



        public static bool UpdateFlightBL(Flight_46004312 newFlight)
        {
            bool FlightAdded = false;

            try
            {
                if (ValidationFlightBL(newFlight))
                {
                    FlightAdded = FlightDAL.UpdateFlightDAL(newFlight);
                }
                else
                {
                    throw new FlightExceptions(Environment.NewLine + "Flight details entered are not Valid!");
                }
            }
            catch (FlightExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return FlightAdded;
        }



        public static bool DeleteFlightBL(int FlightId)
        {
            bool FlightAdded = false;
            try
            {               
                    FlightAdded = FlightDAL.DeleteFlightDAL(FlightId);                
            }
            catch (FlightExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return FlightAdded;
        }

        public static List<Flight_46004312> GetAllFlightsBL()
        {
            List<Flight_46004312> FlightList = new List<Flight_46004312>();
            try
            {
                FlightList= FlightDAL.GetAllFlightsDAL();
            }
            catch (FlightExceptions ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return FlightList;
        }
    }
}
