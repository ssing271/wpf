﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlightException
{
    public class FlightExceptions:ApplicationException
    {
        public FlightExceptions(string message) : base(message)
        {
        }

        public FlightExceptions()
        {
            
        }
    }
}
